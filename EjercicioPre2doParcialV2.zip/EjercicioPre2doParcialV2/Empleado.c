#include "Empleado.h"

void em_calcularSueldo(void* p)
{

}
